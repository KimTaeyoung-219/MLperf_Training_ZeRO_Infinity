.. _testedsystems:

Tested systems
================
So far we have tested DLIO on the following systems: 
  * Personal workstation, laptops including both MacOSX and Linux OS system. 
  * Supercomputers (Linux), such as Theta @ ALCF, Summit @ OLCF, Lassen @ LLNL (please turn to: `instructions_lassen.rst`_ for instructions)
